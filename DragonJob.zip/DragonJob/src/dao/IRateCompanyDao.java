package dao;

import java.util.List;

import entity.Ratejob;

public interface IRateCompanyDao {
    public void insertCompany(Ratejob ratejob);
    public List<Ratejob> queryJob(Ratejob ratejob);
    public List<Ratejob> queryCompany(Ratejob ratejob);
    public List<Ratejob> querySinglePhoto(Ratejob ratejob);
    public List<Ratejob> queryCompanyWithName(Ratejob ratejob);
    public List<Ratejob> queryCompanyPosition(Ratejob ratejob);
}
