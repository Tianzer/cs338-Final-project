package dao;



import entity.Users;

public interface IUserDao {
   public void insertUser(Users u);
   public Users queryUser(Users u);
   public Users queryUserName(Users u);
   public Users queryAuthor(Users u);
}
