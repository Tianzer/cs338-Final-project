package dao.impl;


import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import dao.IUserDao;
import entity.Users;

public class UserDaoImpl extends HibernateDaoSupport implements IUserDao{

	@Override
	public void insertUser(Users u) {
		// TODO Auto-generated method stub
		
		HibernateTemplate ht = getHibernateTemplate();
		ht.save(u);
	}

	@Override
	public Users queryUser(Users u) {
		// TODO Auto-generated method stub
		String hql = "from Users u where u.idname=? and u.password=?";
		List<Users> list = getHibernateTemplate().find(hql,u.getIdname(),u.getPassword());
		if(list.size() > 0){
			return list.get(0);
		}
		
		return null;	
	}

	@Override
	public Users queryUserName(Users u) {
		// TODO Auto-generated method stub
		String hql = "from Users u where u.idname=?";
		List<Users> list = getHibernateTemplate().find(hql,u.getIdname());
		if (list.size() > 0){
			return list.get(0);
		}else{
			return null;
		}
	}

	@Override
	public Users queryAuthor(Users u) {
		// TODO Auto-generated method stub
		String hql = "from Users u where u.id=?";
		List<Users> list = getHibernateTemplate().find(hql,u.getId());
		if (list.size() > 0){
			return list.get(0);
		}else{
			return null;
		}
	}


}
