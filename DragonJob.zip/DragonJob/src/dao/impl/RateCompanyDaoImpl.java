package dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import dao.IRateCompanyDao;
import entity.Ratejob;

public class RateCompanyDaoImpl extends HibernateDaoSupport implements IRateCompanyDao{

	@Override
	public void insertCompany(Ratejob ratejob) {
		// TODO Auto-generated method stub
		HibernateTemplate ht = getHibernateTemplate();
		ht.save(ratejob);
	}

	@Override
	public List<Ratejob> queryJob(Ratejob ratejob) {
       // TODO Auto-generated method stub
		String hql = "from Ratejob rj where rj.name=? and rj.position=?";
		return getHibernateTemplate().find(hql,ratejob.getName(),ratejob.getPosition());
	}

	@Override
	public List<Ratejob> queryCompany(Ratejob ratejob) {
		// TODO Auto-generated method stub
		return getHibernateTemplate().find("from Ratejob r where r.id=?",ratejob.getId());
	}

	@Override
	public List<Ratejob> querySinglePhoto(Ratejob ratejob) {
		// TODO Auto-generated method stub
		
		return getHibernateTemplate().find(" from Ratejob r where r.id=?",ratejob.getId());
	}

	@Override
	public List<Ratejob> queryCompanyWithName(Ratejob ratejob) {
		// TODO Auto-generated method stub
		//SessionFactory  sf =  new Configuration().configure().buildSessionFactory();
		
		//Session session = sf.openSession();
		String hql = "from Ratejob r where r.name like ? order by r.name";
		
		return  getHibernateTemplate().find(hql,ratejob.getName()+"%");
	}

	@Override
	public List<Ratejob> queryCompanyPosition(Ratejob ratejob) {
		// TODO Auto-generated method stub
		return getHibernateTemplate().find(
				"from Ratejob r where r.name=?",ratejob.getName());
	}



	


}
