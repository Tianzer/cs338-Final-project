package action;

import com.opensymphony.xwork2.ActionContext;

import entity.Users;
import biz.IUsersBiz;

public class LoginAction {
	private IUsersBiz qub;
	private String username;
	private String password;
	private IUsersBiz ub;
	private Users u;

	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public IUsersBiz getQub() {
		return qub;
	}


	public void setQub(IUsersBiz qub) {
		this.qub = qub;
	}

    //��¼��֤
	public String login(){
		Users  user = qub.queryUser(u);
		if(user != null){
				
			ActionContext.getContext().getSession().put("user", user);
			System.out.println("��¼�ɹ�");
			return "success";
				
		}
		  System.out.println("��¼ʧ��");
		  return "fail";	
	
	}
	
	//����¼��
	public String checkName(){
		Users user = new Users();
		user.setIdname(username);
	    user = qub.queryUserName(user);
	    
		if(user != null){
			
			return "succeed";
		}
		
		return "noUser";
	}
	
	public String register(){
		Users user = u;
		user = qub.queryUserName(u);
		if(user == null){
			qub.addUser(u);
			return "success";
		}
		return "fail";
	}


	public IUsersBiz getUb() {
		return ub;
	}


	public void setUb(IUsersBiz ub) {
		this.ub = ub;
	}


	public Users getU() {
		return u;
	}


	public void setU(Users u) {
		this.u = u;
	}
	
}
