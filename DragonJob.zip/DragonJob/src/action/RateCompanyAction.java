package action;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;


import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import biz.ICompanyBiz;
import biz.IUsersBiz;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

import entity.Ratejob;
import entity.Users;



public class RateCompanyAction extends ActionSupport{
		
	    private IUsersBiz iuser;
		private Ratejob rj;
		private ICompanyBiz icb;
		
		private List<Ratejob> list;
		private List<Ratejob> listPosition;
		
		
		private File photo1;
		private File photo2;
		private File photo3;
		
		
		private String salary;
		private String location;
		private String skills;
		private String process;
		private String descript;
		private String position;
		
		private String searcheName;
		private String number;
		
		public String getSalary() {
			return salary;
		}

		public void setSalary(String salary) {
			this.salary = salary;
		}

		public String getLocation() {
			return location;
		}

		public void setLocation(String location) {
			this.location = location;
		}

		public String getSkills() {
			return skills;
		}

		public void setSkills(String skills) {
			this.skills = skills;
		}

		public String getProcess() {
			return process;
		}

		public void setProcess(String process) {
			this.process = process;
		}

		public String getDescript() {
			return descript;
		}

		public void setDescript(String descript) {
			this.descript = descript;
		}
   
		 
		public String suc(){
			try{
		    Integer i = Integer.parseInt(number);
		    List<Ratejob> getList =  
		    (List<Ratejob>) ActionContext.getContext().getSession().get("jobList");
		    Ratejob rb =  getList.get(i);
		    ActionContext.getContext().getSession().put("salarys",rb.getSalary());
		    ActionContext.getContext().getSession().put("locations",rb.getLocation());
		    ActionContext.getContext().getSession().put("skillses",rb.getSkills());
		    ActionContext.getContext().getSession().put("processes",rb.getInterviewProcess());
		    ActionContext.getContext().getSession().put("des",rb.getJobDescription());
		    ActionContext.getContext().getSession().put("rate",rb);
		    ActionContext.getContext().getSession().put("page",number);
		      Users u = new Users();
			  u.setId(getList.get(0).getUsers().getId());
			  Users author = iuser.queryAuthor(u);
		    ActionContext.getContext().getSession().put("author",author);
		    
			}catch(Exception e){
				e.printStackTrace();
			}
			return "success";
		}
		
		
	    
		//find job
		public String findJob(){
		
		  List<Ratejob> listJob = icb.queryJob(rj);
		  ActionContext.getContext().getSession().put("jobList",listJob);
		  
		  ActionContext.getContext().getSession().put("rate",listJob.get(0));
		  Users u = new Users();
		  u.setId(listJob.get(0).getUsers().getId());
		  Users author = iuser.queryAuthor(u);
		  ActionContext.getContext().getSession().put("author",author);
		  System.out.println("position is"+rj.getPosition());
		  System.out.println("name is"+rj.getName());
		  if(listJob.size()>0){return "success";}
		  return "fail";
	    }
		
		public String findPosition(){
			Ratejob ratejob = new Ratejob();
			ratejob.setName(searcheName);
		    List<Ratejob> ls = icb.queryComPosition(ratejob);
		    List<Ratejob> ls2 = new ArrayList<Ratejob>();
			boolean flag = true;
			if(ls.size()>0){
				for(int i=0;i<ls.size();i++){
					System.out.println(ls.get(i).getPosition());
				   if(ls2.size()>0){
					   for(Ratejob var : ls2){
						   if(var.getPosition().equals(ls.get(i).getPosition())){
							   flag = false;
						   }else{
							   flag = true;
						   }
					   }
					   if(flag){
						   ls2.add(ls.get(i));
					   }
				   }else{
					   ls2.add(ls.get(i));
				   }
				}
			}
		     listPosition = ls2;
			return "success";
			
		}
		
		
		
		
		//find company by name
		public String findCombyName(){
			 try{
			Ratejob ratejob = new Ratejob();
			ratejob.setName(searcheName);
			List<Ratejob> ls = icb.queryComByName(ratejob);
			System.out.println("查找公司名："+ratejob.getName());
			//ActionContext.getContext().getSession().put("list",list);
			List<Ratejob> ls2 = new ArrayList<Ratejob>();
			boolean flag = true;
			if(ls.size()>0){
				for(int i=0;i<ls.size();i++){
					System.out.println(ls.get(i).getName());
				   if(ls2.size()>0){
					   for(Ratejob var : ls2){
						   if(var.getName().equals(ls.get(i).getName())){
							   flag = false;
						   }else{
							   flag = true;
						   }
					   }
					   if(flag){
						   ls2.add(ls.get(i));
					   }
				   }else{
					   ls2.add(ls.get(i));
				   }
				}
			}
			list = ls2;
			}catch(Exception e){
				 e.printStackTrace();
			 }
			return "success";
		}
		
		//query single photo
		public String querySinglePhoto(){
			
			Ratejob rate = (Ratejob) ActionContext.getContext().getSession().get("rate");
			rate = icb.querySinglePhoto(rate);
			if(rate.getPhoto1() != null){
			byte[] picture = rate.getPhoto1();
			HttpServletResponse re = ServletActionContext.getResponse();
			try {
				
				InputStream str = new ByteArrayInputStream(picture);
				byte[] buffer = new byte[1024];
				int len = 0;
				do{
					len = str.read(buffer);
					if(len>0)
					  re.getOutputStream().write(buffer,0,len);
				}while(len > 0);
				re.getOutputStream().flush();
				re.getOutputStream().close();
			 
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 }
			return null;		
		}
        
		public String querySinglePhoto2(){
			Ratejob rate = (Ratejob) ActionContext.getContext().getSession().get("rate");
			rate = icb.querySinglePhoto(rate);
			if(rate.getPhoto2() != null){
			byte[] picture = rate.getPhoto2();
			HttpServletResponse re = ServletActionContext.getResponse();
			try {
				InputStream str = new ByteArrayInputStream(picture);
				byte[] buffer = new byte[1024];
				int len = 0;
				do{
					len = str.read(buffer);
					if(len>0)
					  re.getOutputStream().write(buffer,0,len);
				}while(len > 0);
				re.getOutputStream().flush();
				re.getOutputStream().close();
						
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
			return null;
			
		}

		public String querySinglePhoto3(){
			
			Ratejob rate = (Ratejob) ActionContext.getContext().getSession().get("rate");
			rate = icb.querySinglePhoto(rate);
			if(rate.getPhoto3() != null){
			byte[] picture = rate.getPhoto3();
			HttpServletResponse re = ServletActionContext.getResponse();
			try {
				InputStream str = new ByteArrayInputStream(picture);
				byte[] buffer = new byte[1024];
				int len = 0;
				do{
					len = str.read(buffer);
					if(len>0)
					  re.getOutputStream().write(buffer,0,len);
				}while(len > 0);
				re.getOutputStream().flush();
				re.getOutputStream().close();
						
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
			return null;		
		}
	
	  	//get Rate name and position
		public String getCompanyName(){
			
		  ActionContext.getContext().getSession().put("CompanyName", rj.getName());
		  ActionContext.getContext().getSession().put("CompanyPosition", rj.getPosition());
		  System.out.println("Rate Name"+rj.getName()+" "+rj.getPosition());
		  return "rateCompanyName";
		}
		
		//rate Job without photos
		public String rateJob(){
          
			String name =
					(String) ActionContext.getContext().getSession().get("CompanyName");
			Users user = (Users) ActionContext.getContext().getSession().get("user");
			String position =
					(String) ActionContext.getContext().getSession().get("CompanyPosition");
			rj.setUsers(user);
			rj.setName(name);
			rj.setPosition(position);
			
			icb.addCompany(rj);
			
			ActionContext.getContext().getSession().put("ratejob", rj);
			
			return "success";
		
		}
	    // jump action to up upload photos
		public String jump(){
			 Ratejob ratejob = new Ratejob();
			String name =
					(String) ActionContext.getContext().getSession().get("CompanyName");
			String position =
					(String) ActionContext.getContext().getSession().get("CompanyPosition");
			Users user = (Users) ActionContext.getContext().getSession().get("user");
			//System.out.println("������"+location);
			//System.out.println("������"+salary);
			//System.out.println("������"+skills);
			//System.out.println("����:"+process);
			//������null123,location=aa,skillsb,processc,descriptdnull
			
			ratejob.setUsers(user);
			ratejob.setName(name);
			ratejob.setLocation(location);
			ratejob.setSalary(salary);
			ratejob.setSkills(skills);
			ratejob.setJobDescription(descript);
			ratejob.setInterviewProcess(process);
			ratejob.setPosition(position);
			ratejob.setPosition(
					(String) ActionContext.getContext().getSession().get("CompanyPosition"));
			
			ActionContext.getContext().getSession().put("rateJob", ratejob);
					
			return "success";
		}
		
		//rate job(include uploading)
		public String uploadPhoto(){
			
			
			Ratejob company =
		    (Ratejob) ActionContext.getContext().getSession().get("rateJob");
			ActionContext.getContext().getSession().put("ratejob", company);
			try {
				if(photo1 != null){
					FileInputStream in = new FileInputStream(photo1);
					byte[] data = new byte[]{};
					data = inputStreamToByte(in);
					company.setPhoto1(data);
				}
				if(photo2 != null){
					FileInputStream in = new FileInputStream(photo2);
					byte[] data = new byte[]{};
					data = inputStreamToByte(in);
					company.setPhoto2(data);
				}
				if(photo3 != null){
					FileInputStream in = new FileInputStream(photo3);
					byte[] data = new byte[]{};
					data = inputStreamToByte(in);
					company.setPhoto3(data);
				}
				
				
				icb.addCompany(company);
			 } catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Upload Fail!");
			}
			return "UploadSucc";

		}
		
		//change type of inputStream file to byte[];
		private byte [] inputStreamToByte(InputStream is) throws IOException{ 
	        ByteArrayOutputStream OutputStream = new ByteArrayOutputStream(); 
	        int ch; 
	        while((ch = is.read() ) != -1){ 
	            OutputStream.write(ch); 
	        } 
	        byte data [] = OutputStream.toByteArray(); 
	        OutputStream.close(); 
	        return data; 
	    } 
		
		
		
		
		
		public ICompanyBiz getIcb() {
			return icb;
		}

		public void setIcb(ICompanyBiz icb) {
			this.icb = icb;
		}

		public Ratejob getRj() {
			return rj;
		}


		public void setRj(Ratejob rj) {
			this.rj = rj;
		}

		public File getPhoto1() {
			return photo1;
		}

		public void setPhoto1(File photo1) {
			this.photo1 = photo1;
		}

		public File getPhoto3() {
			return photo3;
		}

		public void setPhoto3(File photo3) {
			this.photo3 = photo3;
		}

		public File getPhoto2() {
			return photo2;
		}

		public void setPhoto2(File photo2) {
			this.photo2 = photo2;
		}


		public String getPosition() {
			return position;
		}

		public void setPosition(String position) {
			this.position = position;
		}

		public String getSearcheName() {
			return searcheName;
		}

		public void setSearcheName(String searcheName) {
			this.searcheName = searcheName;
		}

		public List<Ratejob> getList() {
			return list;
		}

		public void setList(List<Ratejob> list) {
			this.list = list;
		}

		public List<Ratejob> getListPosition() {
			return listPosition;
		}

		public void setListPosition(List<Ratejob> listPosition) {
			this.listPosition = listPosition;
		}

		public String getNumber() {
			return number;
		}

		public void setNumber(String number) {
			this.number = number;
		}

		public IUsersBiz getIuser() {
			return iuser;
		}

		public void setIuser(IUsersBiz iuser) {
			this.iuser = iuser;
		}

}
