package biz.impl;


import java.util.List;

import dao.IRateCompanyDao;
import entity.Ratejob;
import biz.ICompanyBiz;

public class RateComanyBizImpl implements ICompanyBiz{
    private IRateCompanyDao IRC;
	
    
	@Override
	public void addCompany(Ratejob ratejob) {
		// TODO Auto-generated method stub
		IRC.insertCompany(ratejob);
	}

	public IRateCompanyDao getIRC() {
		return IRC;
	}

	public void setIRC(IRateCompanyDao iRC) {
		IRC = iRC;
	}

	@Override
	public List<Ratejob> queryJob(Ratejob ratejob) {
		// TODO Auto-generated method stub
			
		return IRC.queryJob(ratejob);
	}

	@Override
	public Ratejob queryCompany(Ratejob ratejob) {
		List<Ratejob> list = IRC.queryCompany(ratejob);
		if(list.size() > 0){
			return list.get(0);	
		}
		return null;
	}

	@Override
	public Ratejob querySinglePhoto(Ratejob ratejob) {
		// TODO Auto-generated method stub
		List<Ratejob> list = IRC.querySinglePhoto(ratejob);
		if(list.size() > 0){
			return list.get(0);	
		}
		return null;
	}

	@Override
	public List<Ratejob> queryComByName(Ratejob ratejob) {
		
		return IRC.queryCompanyWithName(ratejob);
	}

	@Override
	public List<Ratejob> queryComPosition(Ratejob ratejob) {
		// TODO Auto-generated method stub
		
		return IRC.queryCompanyPosition(ratejob);
	}

}
