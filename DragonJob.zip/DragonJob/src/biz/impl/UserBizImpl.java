package biz.impl;


import dao.IUserDao;
import entity.Users;
import biz.IUsersBiz;

public class UserBizImpl implements IUsersBiz{
    private IUserDao ud;
	
	
	public IUserDao getUd() {
		return ud;
	}



	public void setUd(IUserDao ud) {
		this.ud = ud;
	}



	@Override
	public Users queryUser(Users u) {
		// TODO Auto-generated method stub
		return ud.queryUser(u);
	}



	@Override
	public void addUser(Users u) {
		// TODO Auto-generated method stub
		ud.insertUser(u);
	}



	@Override
	public Users queryUserName(Users u) {
		// TODO Auto-generated method stub
		
		return ud.queryUserName(u);
	}



	@Override
	public Users queryAuthor(Users u) {
		// TODO Auto-generated method stub
		
		return ud.queryAuthor(u);
	}




	


}
