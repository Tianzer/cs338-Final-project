package biz;


import entity.Users;

public interface IUsersBiz {
	public Users queryUser(Users u);
	public void addUser(Users u);
	public Users queryUserName(Users u);
	public Users queryAuthor(Users u);
}
