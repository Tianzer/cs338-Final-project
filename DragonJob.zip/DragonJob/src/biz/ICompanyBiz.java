package biz;

import java.util.List;

import entity.Ratejob;

public interface ICompanyBiz {
    public void addCompany(Ratejob ratejob);
   // public void addPhoto(Ratejob rate);
    public List<Ratejob> queryJob(Ratejob ratejob);
    public Ratejob queryCompany(Ratejob ratejob); 
    public Ratejob querySinglePhoto(Ratejob ratejob);
    public List<Ratejob> queryComByName(Ratejob ratejob);
    public List<Ratejob> queryComPosition(Ratejob ratejob);
}